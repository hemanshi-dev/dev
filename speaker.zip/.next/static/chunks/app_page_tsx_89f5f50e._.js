(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_a1b13bc1._.js",
  "static/chunks/app_RecordingPage_b5e1d176.css"
],
    source: "dynamic"
});
