(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// "use client";
// import { useEffect, useRef, useState } from "react";
// import "./RecordingPage.css";
// export default function Home() {
//   const [isRecording, setIsRecording] = useState(false);
//   const socketRef = useRef<WebSocket | null>(null);
//   const mediaRecorderRef = useRef<MediaRecorder | null>(null);
//   // const startRecording = async () => {
//   //   try {
//   //     // ADD THIS: Send start signal FIRST
//   //     if (socketRef.current?.readyState === WebSocket.OPEN) {
//   //       console.log("📡 Sending START signal");
//   //       socketRef.current.send(JSON.stringify({ type: "start" }));
//   //     }
//   //     const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
//   //     const mediaRecorder = new MediaRecorder(stream, {
//   //       mimeType: "audio/webm",
//   //     });
//   //     mediaRecorder.ondataavailable = async (event) => {
//   //       if (
//   //         event.data.size > 0 &&
//   //         socketRef.current?.readyState === WebSocket.OPEN
//   //       ) {
//   //         const buffer = await event.data.arrayBuffer();
//   //         console.log(`Sending ${buffer.byteLength} bytes of data`);
//   //         socketRef.current.send(buffer);
//   //       }
//   //     };
//   //     mediaRecorder.start(1000);
//   //     mediaRecorderRef.current = mediaRecorder;
//   //     setIsRecording(true);
//   //   } catch (error) {
//   //     console.error("Error accessing media devices:", error);
//   //   }
//   // };
//   const startRecording = async () => {
//     try {
//       const devices = await navigator.mediaDevices.enumerateDevices();
//       const audioDevices = devices.filter((device) => device.kind === "audioinput");
//       if (audioDevices.length === 0) {
//         console.error("No audio input devices found.");
//         alert("No microphone detected. Please connect a microphone and try again.");
//         return;
//       }
//       if (socketRef.current?.readyState === WebSocket.OPEN) {
//         console.log("📡 Sending START signal");
//         socketRef.current.send(JSON.stringify({ type: "start" }));
//       }
//       const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
//       const mediaRecorder = new MediaRecorder(stream, {
//         mimeType: "audio/webm",
//       });
//       mediaRecorder.ondataavailable = async (event) => {
//         if (
//           event.data.size > 0 &&
//           socketRef.current?.readyState === WebSocket.OPEN
//         ) {
//           const buffer = await event.data.arrayBuffer();
//           console.log(`Sending ${buffer.byteLength} bytes of data`);
//           socketRef.current.send(buffer);
//         }
//       };
//       mediaRecorder.start(1000);
//       mediaRecorderRef.current = mediaRecorder;
//       setIsRecording(true);
//     } catch (error) {
//       console.error("Error accessing media devices:", error);
//       alert("Failed to access microphone. Please check your browser permissions.");
//     }
//   };
//   const stopRecording = () => {
//     mediaRecorderRef.current?.stop();
//     mediaRecorderRef.current = null;
//     // ADD THIS: Send stop signal
//     if (socketRef.current?.readyState === WebSocket.OPEN) {
//       console.log("📡 Sending STOP signal");
//       socketRef.current.send(JSON.stringify({ type: "stop" }));
//     }
//     setIsRecording(false);
//   };
//   // const stopRecording = () => {
//   //   mediaRecorderRef.current?.stop();
//   //   mediaRecorderRef.current = null;
//   //   setIsRecording(false);
//   // };
//   const toggleRecording = () => {
//     console.log("Toggling recording. Current state:", !isRecording);
//     if (!isRecording) {
//       startRecording();
//     } else {
//       stopRecording();
//     }
//   };
//   useEffect(() => {
//     const socket = new WebSocket("ws://localhost:8082/?role=broadcaster");
//     // const socket = new WebSocket(
//       // "wss://devcoreact-production.up.railway.app/?role=broadcaster"
//     // );
//     socketRef.current = socket;
//     socket.onopen = () => {
//       console.log("WebSocket connection opened.");
//     };
//     socket.onclose = () => {
//       console.log("WebSocket connection closed.");
//     };
//     socket.onerror = (error) => {
//       console.error("WebSocket error:", error);
//     };
//     return () => {
//       socket.close();
//     };
//   }, []);
//   return (
//     <div className="container">
//       <div className="content">
//         <h1 className="title">Auction Speaker</h1>
//         <button
//           className={`record-button ${isRecording ? "recording" : "record"}`}
//           onClick={toggleRecording}
//         ></button>
//         <div className="recording-status">
//           {isRecording ? (
//             <>
//               <span className="recording-indicator"></span> Recording...
//             </>
//           ) : (
//             "Click to start recording"
//           )}
//         </div>
//       </div>
//     </div>
//   );
// }
__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
// CONFIGURATION - Change this to your server URL
const SERVER_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_SERVER_URL || "ws://localhost:8082";
function Home() {
    _s();
    const [isRecording, setIsRecording] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [connectionStatus, setConnectionStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("disconnected");
    const socketRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const mediaRecorderRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const reconnectTimeoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const connectWebSocket = ()=>{
        var _socketRef_current;
        if (((_socketRef_current = socketRef.current) === null || _socketRef_current === void 0 ? void 0 : _socketRef_current.readyState) === WebSocket.OPEN) {
            console.log("WebSocket already connected");
            return;
        }
        setConnectionStatus("connecting");
        const socket = new WebSocket("".concat(SERVER_URL, "/?role=broadcaster"));
        socketRef.current = socket;
        socket.onopen = ()=>{
            console.log("✅ WebSocket connection opened");
            setConnectionStatus("connected");
            // Clear any pending reconnect
            if (reconnectTimeoutRef.current) {
                clearTimeout(reconnectTimeoutRef.current);
                reconnectTimeoutRef.current = null;
            }
        };
        socket.onmessage = (event)=>{
            try {
                const data = JSON.parse(event.data);
                console.log("📩 Server message:", data);
            } catch (e) {
                console.error("Failed to parse server message:", e);
            }
        };
        socket.onclose = ()=>{
            console.log("❌ WebSocket connection closed");
            setConnectionStatus("disconnected");
            // Auto-reconnect after 3 seconds
            reconnectTimeoutRef.current = setTimeout(()=>{
                console.log("🔄 Attempting to reconnect...");
                connectWebSocket();
            }, 3000);
        };
        socket.onerror = (error)=>{
            console.error("❌ WebSocket error:", error);
            setConnectionStatus("disconnected");
        };
    };
    const startRecording = async ()=>{
        try {
            var _socketRef_current;
            // Check if microphone is available
            const devices = await navigator.mediaDevices.enumerateDevices();
            const audioDevices = devices.filter((device)=>device.kind === "audioinput");
            if (audioDevices.length === 0) {
                console.error("No audio input devices found");
                alert("No microphone detected. Please connect a microphone and try again.");
                return;
            }
            // Ensure WebSocket is connected
            if (((_socketRef_current = socketRef.current) === null || _socketRef_current === void 0 ? void 0 : _socketRef_current.readyState) !== WebSocket.OPEN) {
                console.error("WebSocket not connected");
                alert("Server connection lost. Reconnecting...");
                connectWebSocket();
                return;
            }
            // Send START signal
            console.log("📡 Sending START signal");
            socketRef.current.send(JSON.stringify({
                type: "start"
            }));
            // Get microphone stream
            const stream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true
                }
            });
            const mediaRecorder = new MediaRecorder(stream, {
                mimeType: "audio/webm"
            });
            mediaRecorder.ondataavailable = async (event)=>{
                var _socketRef_current;
                if (event.data.size > 0 && ((_socketRef_current = socketRef.current) === null || _socketRef_current === void 0 ? void 0 : _socketRef_current.readyState) === WebSocket.OPEN) {
                    const buffer = await event.data.arrayBuffer();
                    console.log("📤 Sending ".concat(buffer.byteLength, " bytes"));
                    socketRef.current.send(buffer);
                }
            };
            mediaRecorder.onerror = (error)=>{
                console.error("MediaRecorder error:", error);
                stopRecording();
            };
            mediaRecorder.start(1000); // Send data every 1 second
            mediaRecorderRef.current = mediaRecorder;
            setIsRecording(true);
            console.log("🎙️ Recording started");
        } catch (error) {
            console.error("Error starting recording:", error);
            alert("Failed to access microphone. Please check your browser permissions.");
        }
    };
    const stopRecording = ()=>{
        var _socketRef_current;
        if (mediaRecorderRef.current) {
            mediaRecorderRef.current.stop();
            // Stop all tracks
            if (mediaRecorderRef.current.stream) {
                mediaRecorderRef.current.stream.getTracks().forEach((track)=>track.stop());
            }
            mediaRecorderRef.current = null;
        }
        // Send STOP signal
        if (((_socketRef_current = socketRef.current) === null || _socketRef_current === void 0 ? void 0 : _socketRef_current.readyState) === WebSocket.OPEN) {
            console.log("📡 Sending STOP signal");
            socketRef.current.send(JSON.stringify({
                type: "stop"
            }));
        }
        setIsRecording(false);
        console.log("⏹️ Recording stopped");
    };
    const toggleRecording = ()=>{
        if (connectionStatus !== "connected") {
            alert("Not connected to server. Please wait...");
            return;
        }
        if (!isRecording) {
            startRecording();
        } else {
            stopRecording();
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            connectWebSocket();
            return ({
                "Home.useEffect": ()=>{
                    // Cleanup on unmount
                    if (reconnectTimeoutRef.current) {
                        clearTimeout(reconnectTimeoutRef.current);
                    }
                    if (mediaRecorderRef.current) {
                        stopRecording();
                    }
                    if (socketRef.current) {
                        socketRef.current.close();
                    }
                }
            })["Home.useEffect"];
        }
    }["Home.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "content",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "title",
                    children: "Auction Speaker"
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 338,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        marginBottom: "20px",
                        padding: "10px",
                        borderRadius: "8px",
                        backgroundColor: connectionStatus === "connected" ? "#d4edda" : connectionStatus === "connecting" ? "#fff3cd" : "#f8d7da",
                        color: connectionStatus === "connected" ? "#155724" : connectionStatus === "connecting" ? "#856404" : "#721c24"
                    },
                    children: [
                        connectionStatus === "connected" && "✅ Connected to server",
                        connectionStatus === "connecting" && "⏳ Connecting...",
                        connectionStatus === "disconnected" && "❌ Disconnected - Reconnecting..."
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 341,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: "record-button ".concat(isRecording ? "recording" : "record"),
                    onClick: toggleRecording,
                    disabled: connectionStatus !== "connected"
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 355,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "recording-status",
                    children: isRecording ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "recording-indicator"
                            }, void 0, false, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 364,
                                columnNumber: 15
                            }, this),
                            " Recording..."
                        ]
                    }, void 0, true) : "Click to start recording"
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 361,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/page.tsx",
            lineNumber: 337,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/page.tsx",
        lineNumber: 336,
        columnNumber: 5
    }, this);
}
_s(Home, "k/cRus2JJMusF1LrbkXm63Nae0g=");
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * @license React
 * react-jsx-dev-runtime.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function getComponentNameFromType(type) {
        if (null == type) return null;
        if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
        if ("string" === typeof type) return type;
        switch(type){
            case REACT_FRAGMENT_TYPE:
                return "Fragment";
            case REACT_PROFILER_TYPE:
                return "Profiler";
            case REACT_STRICT_MODE_TYPE:
                return "StrictMode";
            case REACT_SUSPENSE_TYPE:
                return "Suspense";
            case REACT_SUSPENSE_LIST_TYPE:
                return "SuspenseList";
            case REACT_ACTIVITY_TYPE:
                return "Activity";
        }
        if ("object" === typeof type) switch("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof){
            case REACT_PORTAL_TYPE:
                return "Portal";
            case REACT_CONTEXT_TYPE:
                return type.displayName || "Context";
            case REACT_CONSUMER_TYPE:
                return (type._context.displayName || "Context") + ".Consumer";
            case REACT_FORWARD_REF_TYPE:
                var innerType = type.render;
                type = type.displayName;
                type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
                return type;
            case REACT_MEMO_TYPE:
                return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
            case REACT_LAZY_TYPE:
                innerType = type._payload;
                type = type._init;
                try {
                    return getComponentNameFromType(type(innerType));
                } catch (x) {}
        }
        return null;
    }
    function testStringCoercion(value) {
        return "" + value;
    }
    function checkKeyStringCoercion(value) {
        try {
            testStringCoercion(value);
            var JSCompiler_inline_result = !1;
        } catch (e) {
            JSCompiler_inline_result = !0;
        }
        if (JSCompiler_inline_result) {
            JSCompiler_inline_result = console;
            var JSCompiler_temp_const = JSCompiler_inline_result.error;
            var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
            JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
            return testStringCoercion(value);
        }
    }
    function getTaskName(type) {
        if (type === REACT_FRAGMENT_TYPE) return "<>";
        if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
        try {
            var name = getComponentNameFromType(type);
            return name ? "<" + name + ">" : "<...>";
        } catch (x) {
            return "<...>";
        }
    }
    function getOwner() {
        var dispatcher = ReactSharedInternals.A;
        return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
        return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
        if (hasOwnProperty.call(config, "key")) {
            var getter = Object.getOwnPropertyDescriptor(config, "key").get;
            if (getter && getter.isReactWarning) return !1;
        }
        return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
        function warnAboutAccessingKey() {
            specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
        }
        warnAboutAccessingKey.isReactWarning = !0;
        Object.defineProperty(props, "key", {
            get: warnAboutAccessingKey,
            configurable: !0
        });
    }
    function elementRefGetterWithDeprecationWarning() {
        var componentName = getComponentNameFromType(this.type);
        didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
        componentName = this.props.ref;
        return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, props, owner, debugStack, debugTask) {
        var refProp = props.ref;
        type = {
            $$typeof: REACT_ELEMENT_TYPE,
            type: type,
            key: key,
            props: props,
            _owner: owner
        };
        null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
            enumerable: !1,
            get: elementRefGetterWithDeprecationWarning
        }) : Object.defineProperty(type, "ref", {
            enumerable: !1,
            value: null
        });
        type._store = {};
        Object.defineProperty(type._store, "validated", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: 0
        });
        Object.defineProperty(type, "_debugInfo", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: null
        });
        Object.defineProperty(type, "_debugStack", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugStack
        });
        Object.defineProperty(type, "_debugTask", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugTask
        });
        Object.freeze && (Object.freeze(type.props), Object.freeze(type));
        return type;
    }
    function jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStack, debugTask) {
        var children = config.children;
        if (void 0 !== children) if (isStaticChildren) if (isArrayImpl(children)) {
            for(isStaticChildren = 0; isStaticChildren < children.length; isStaticChildren++)validateChildKeys(children[isStaticChildren]);
            Object.freeze && Object.freeze(children);
        } else console.error("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
        else validateChildKeys(children);
        if (hasOwnProperty.call(config, "key")) {
            children = getComponentNameFromType(type);
            var keys = Object.keys(config).filter(function(k) {
                return "key" !== k;
            });
            isStaticChildren = 0 < keys.length ? "{key: someKey, " + keys.join(": ..., ") + ": ...}" : "{key: someKey}";
            didWarnAboutKeySpread[children + isStaticChildren] || (keys = 0 < keys.length ? "{" + keys.join(": ..., ") + ": ...}" : "{}", console.error('A props object containing a "key" prop is being spread into JSX:\n  let props = %s;\n  <%s {...props} />\nReact keys must be passed directly to JSX without using spread:\n  let props = %s;\n  <%s key={someKey} {...props} />', isStaticChildren, children, keys, children), didWarnAboutKeySpread[children + isStaticChildren] = !0);
        }
        children = null;
        void 0 !== maybeKey && (checkKeyStringCoercion(maybeKey), children = "" + maybeKey);
        hasValidKey(config) && (checkKeyStringCoercion(config.key), children = "" + config.key);
        if ("key" in config) {
            maybeKey = {};
            for(var propName in config)"key" !== propName && (maybeKey[propName] = config[propName]);
        } else maybeKey = config;
        children && defineKeyPropWarningGetter(maybeKey, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
        return ReactElement(type, children, maybeKey, getOwner(), debugStack, debugTask);
    }
    function validateChildKeys(node) {
        "object" === typeof node && null !== node && node.$$typeof === REACT_ELEMENT_TYPE && node._store && (node._store.validated = 1);
    }
    var React = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"), REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_ACTIVITY_TYPE = Symbol.for("react.activity"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"), ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, hasOwnProperty = Object.prototype.hasOwnProperty, isArrayImpl = Array.isArray, createTask = console.createTask ? console.createTask : function() {
        return null;
    };
    React = {
        react_stack_bottom_frame: function(callStackForError) {
            return callStackForError();
        }
    };
    var specialPropKeyWarningShown;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = React.react_stack_bottom_frame.bind(React, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutKeySpread = {};
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.jsxDEV = function(type, config, maybeKey, isStaticChildren) {
        var trackActualOwner = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
        return jsxDEVImpl(type, config, maybeKey, isStaticChildren, trackActualOwner ? Error("react-stack-top-frame") : unknownOwnerDebugStack, trackActualOwner ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
}();
}),
"[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)");
}
}),
]);

//# sourceMappingURL=_a1b13bc1._.js.map